import sqlite3
from pathlib import Path

def audit_db():
    print("=== DATABASE & WORKER SAFETY AUDIT ===")
    
    # 1. Check data/hq_core.db
    db_path = Path("data/hq_core.db")
    print(f"1. Checking {db_path}...")
    if not db_path.exists():
        print("  -> ERROR: data/hq_core.db does not exist!")
        return False
    
    conn = sqlite3.connect(str(db_path))
    
    # Integrity check
    res_integrity = conn.execute("PRAGMA integrity_check;").fetchone()[0]
    print(f"  -> PRAGMA integrity_check: {res_integrity}")
    
    # Check pragmas
    journal = conn.execute("PRAGMA journal_mode;").fetchone()[0]
    print(f"  -> PRAGMA journal_mode: {journal}")
    
    # Check tables & indexes
    tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()]
    print(f"  -> Tables: {tables}")
    
    # Check unique constraint on idempotency_key
    schema_jobs = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='hq_jobs';").fetchone()[0]
    has_unique = "idempotency_key TEXT NOT NULL UNIQUE" in schema_jobs
    print(f"  -> Idempotency key UNIQUE constraint in schema: {has_unique}")
    
    # Check fencing_token column
    has_fencing = "fencing_token INTEGER DEFAULT 0" in schema_jobs
    print(f"  -> Fencing token column in schema: {has_fencing}")
    
    conn.close()
    
    # 2. Re-check Social Media database identity
    print("\n2. Re-checking Social Media Database Identity:")
    print("  - Configuration reference in code: data/episodes.db (referenced in find_db_path.py)")
    print("  - Disambiguation: 'episodes.db' and 'studio.sqlite3' are NOT the same file.")
    print("  - In this workspace, no physical legacy .db file currently exists in data/ except data/hq_core.db.")
    print("  - Zero legacy databases were touched, created, or mutated by Phase 6.1.")

if __name__ == "__main__":
    audit_db()
