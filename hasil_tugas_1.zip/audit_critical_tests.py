import sys
import os
import time
import threading
import sqlite3
import concurrent.futures
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.hq.queue import HQJobQueue
from src.hq.worker import HQWorker
from src.hq.models import JobStatus, JobPriority, JobBudget

AUDIT_DB_PATH = Path("data/hq_audit_verification.db")

def run_critical_audit():
    print("======================================================================")
    print("MARU HQ — PHASE 6.1 CRITICAL TEST SUITE (12 SPECIFIC CHECKS)")
    print("======================================================================\n")

    if AUDIT_DB_PATH.exists():
        AUDIT_DB_PATH.unlink()

    # Inisialisasi Queue dengan lease singkat (2.0s) untuk pengujian timeout/stale
    q = HQJobQueue(db_path=AUDIT_DB_PATH, lease_duration_sec=2.0)

    results = {}

    # -------------------------------------------------------------------------
    # TEST 1: Concurrent enqueue dengan idempotency key identik
    # -------------------------------------------------------------------------
    print("[TEST 1] Concurrent enqueue with identical idempotency key...")
    def enqueue_worker(idx):
        return q.enqueue(
            division="SOCIAL_MEDIA",
            requested_by=f"USER_{idx}",
            goal="Concurrent Idempotency Test",
            input_payload={"idx": idx},
            acceptance_criteria=["Criterion 1"],
            assigned_agent="EMP-L02",
            idempotency_key="CONCURRENT-KEY-999"
        )

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(enqueue_worker, i) for i in range(5)]
        jobs = [f.result() for f in concurrent.futures.as_completed(futures)]

    task_ids = set(j.task_id for j in jobs)
    all_jobs_in_db = q.list_jobs()
    test1_pass = (len(task_ids) == 1) and (len(all_jobs_in_db) == 1)
    results["TEST_1"] = ("PASS" if test1_pass else "FAIL", f"Unique task_ids returned: {len(task_ids)}, Total rows in DB: {len(all_jobs_in_db)}")
    print(f"  -> Result: {results['TEST_1'][0]} ({results['TEST_1'][1]})")

    # -------------------------------------------------------------------------
    # TEST 2: Dua worker mengambil antrean secara bersamaan
    # -------------------------------------------------------------------------
    print("\n[TEST 2] Two workers competing for lease concurrently...")
    acquired_leases = []
    def acquire_worker(w_id):
        lease = q.acquire_lease(worker_id=w_id)
        if lease:
            acquired_leases.append((w_id, lease))

    t_w1 = threading.Thread(target=acquire_worker, args=("WORKER_PARALLEL_A",))
    t_w2 = threading.Thread(target=acquire_worker, args=("WORKER_PARALLEL_B",))
    t_w1.start(); t_w2.start()
    t_w1.join(); t_w2.join()

    test2_pass = (len(acquired_leases) == 1)
    winner = acquired_leases[0][0] if acquired_leases else "None"
    results["TEST_2"] = ("PASS" if test2_pass else "FAIL", f"Leases granted: {len(acquired_leases)}, Winner: {winner}")
    print(f"  -> Result: {results['TEST_2'][0]} ({results['TEST_2'][1]})")

    active_job = acquired_leases[0][1]
    active_worker = acquired_leases[0][0]

    # -------------------------------------------------------------------------
    # TEST 3: Lease renewal saat pekerjaan berjalan
    # -------------------------------------------------------------------------
    print("\n[TEST 3] Lease renewal while job is running...")
    initial_expiry = active_job.lease_expires_at
    time.sleep(0.5)
    renew_success = q.renew_lease(worker_id=active_worker, task_id=active_job.task_id, fencing_token=active_job.fencing_token)
    refreshed_job = q.get_job(active_job.task_id)
    new_expiry = refreshed_job.lease_expires_at
    test3_pass = renew_success and (new_expiry > initial_expiry)
    results["TEST_3"] = ("PASS" if test3_pass else "FAIL", f"Renewed: {renew_success}, Initial Exp: {initial_expiry:.2f}, New Exp: {new_expiry:.2f}")
    print(f"  -> Result: {results['TEST_3'][0]} ({results['TEST_3'][1]})")

    # -------------------------------------------------------------------------
    # TEST 4: Worker lama mencoba complete_job menggunakan fencing token kedaluwarsa
    # -------------------------------------------------------------------------
    print("\n[TEST 4] Stale worker complete_job with expired fencing token...")
    # Simulate an increment in fencing token by recovering or re-leasing
    # Here we simulate an invalid token directly
    bad_token = active_job.fencing_token - 1
    complete_bad = q.complete_job(worker_id=active_worker, task_id=active_job.task_id, fencing_token=bad_token, result_payload={"msg": "bad"})
    test4_pass = (complete_bad is False)
    results["TEST_4"] = ("PASS" if test4_pass else "FAIL", f"complete_job with bad token rejected: {not complete_bad}")
    print(f"  -> Result: {results['TEST_4'][0]} ({results['TEST_4'][1]})")

    # -------------------------------------------------------------------------
    # TEST 5: Worker crash dan stale lease recovery
    # -------------------------------------------------------------------------
    print("\n[TEST 5] Worker crash and stale lease recovery...")
    print("  -> Waiting 2.2s for lease to expire naturally...")
    time.sleep(2.2)
    recovered_count = q.recover_stale_jobs(actor="AUDIT_DAEMON")
    job_after_recovery = q.get_job(active_job.task_id)
    test5_pass = (recovered_count == 1) and (job_after_recovery.status == JobStatus.QUEUED.value) and (job_after_recovery.fencing_token > active_job.fencing_token)
    results["TEST_5"] = ("PASS" if test5_pass else "FAIL", f"Recovered count: {recovered_count}, Status: {job_after_recovery.status}, New Token: {job_after_recovery.fencing_token}")
    print(f"  -> Result: {results['TEST_5'][0]} ({results['TEST_5'][1]})")

    # -------------------------------------------------------------------------
    # TEST 6: Komputer/aplikasi restart ketika Job berstatus RUNNING / LEASED
    # -------------------------------------------------------------------------
    print("\n[TEST 6] Simulated crash & restart while Job is LEASED...")
    # Acquire lease again with worker C
    lease_w_c = q.acquire_lease(worker_id="WORKER_C")
    assert lease_w_c is not None
    # Simulate restart: delete queue object, close connections, re-instantiate
    del q
    time.sleep(2.2) # simulate downtime past lease expiry
    q_restarted = HQJobQueue(db_path=AUDIT_DB_PATH, lease_duration_sec=2.0)
    recovered_post_restart = q_restarted.recover_stale_jobs(actor="STARTUP_RECOVERY")
    job_post_restart = q_restarted.get_job(lease_w_c.task_id)
    test6_pass = (recovered_post_restart == 1) and (job_post_restart.status == JobStatus.QUEUED.value)
    results["TEST_6"] = ("PASS" if test6_pass else "FAIL", f"Recovered on startup: {recovered_post_restart}, Restored Status: {job_post_restart.status}")
    print(f"  -> Result: {results['TEST_6'][0]} ({results['TEST_6'][1]})")

    # -------------------------------------------------------------------------
    # TEST 7: Retry sampai batas maksimal tiga percobaan
    # -------------------------------------------------------------------------
    print("\n[TEST 7] Retry progression up to max 3 attempts...")
    # Job currently has attempts=2 (from w1 and w_c). Let's check attempts:
    current_job = q_restarted.get_job(job_post_restart.task_id)
    print(f"  -> Current attempts so far: {current_job.attempts}/3")
    # Acquire attempt 3
    lease_att3 = q_restarted.acquire_lease("WORKER_ATTEMPT_3")
    assert lease_att3 is not None
    test7_pass = (lease_att3.attempts == 3)
    results["TEST_7"] = ("PASS" if test7_pass else "FAIL", f"Attempt reached: {lease_att3.attempts}/3, Status: {lease_att3.status}")
    print(f"  -> Result: {results['TEST_7'][0]} ({results['TEST_7'][1]})")

    # -------------------------------------------------------------------------
    # TEST 8: Perpindahan Job ke DEAD_LETTER
    # -------------------------------------------------------------------------
    print("\n[TEST 8] Job transition to DEAD_LETTER when attempts reach max...")
    q_restarted.fail_job("WORKER_ATTEMPT_3", lease_att3.task_id, lease_att3.fencing_token, "Final attempt failure")
    job_dlq = q_restarted.get_job(lease_att3.task_id)
    test8_pass = (job_dlq.status == JobStatus.DEAD_LETTER.value) and (job_dlq.attempts == 3)
    results["TEST_8"] = ("PASS" if test8_pass else "FAIL", f"Final Status: {job_dlq.status}, Attempts: {job_dlq.attempts}")
    print(f"  -> Result: {results['TEST_8'][0]} ({results['TEST_8'][1]})")

    # -------------------------------------------------------------------------
    # TEST 9: Cancel Job ketika worker sedang aktif
    # -------------------------------------------------------------------------
    print("\n[TEST 9] Cancel job while worker is actively leasing...")
    # Create fresh job
    job_to_cancel = q_restarted.enqueue(
        division="SOCIAL_MEDIA", requested_by="USER_CANCEL", goal="Cancel test",
        input_payload={}, acceptance_criteria=[], assigned_agent="EMP-L02", idempotency_key="CANCEL-KEY-001"
    )
    lease_to_cancel = q_restarted.acquire_lease("WORKER_RUNNING_CANCEL")
    assert lease_to_cancel is not None
    # User cancels job
    cancel_success = q_restarted.cancel_job(job_to_cancel.task_id, actor="PEMILIK_HQ", reason="Emergency Stop")
    job_cancelled = q_restarted.get_job(job_to_cancel.task_id)
    # Stale worker tries to complete job after cancellation
    stale_worker_complete = q_restarted.complete_job("WORKER_RUNNING_CANCEL", job_to_cancel.task_id, lease_to_cancel.fencing_token, {"out": "late"})
    job_after_stale = q_restarted.get_job(job_to_cancel.task_id)
    test9_pass = cancel_success and (job_cancelled.status == JobStatus.CANCELLED.value) and (stale_worker_complete is False) and (job_after_stale.status == JobStatus.CANCELLED.value)
    results["TEST_9"] = ("PASS" if test9_pass else "FAIL", f"Cancelled: {cancel_success}, Stale Complete Rejected: {not stale_worker_complete}, Status: {job_after_stale.status}")
    print(f"  -> Result: {results['TEST_9'][0]} ({results['TEST_9'][1]})")

    # -------------------------------------------------------------------------
    # TEST 10: Integritas event log setelah seluruh transisi
    # -------------------------------------------------------------------------
    print("\n[TEST 10] Event log audit trail integrity...")
    logs = q_restarted.get_event_logs(job_to_cancel.task_id)
    log_types = [l["event_type"] for l in logs]
    test10_pass = ("JOB_ENQUEUED" in log_types) and ("LEASE_ACQUIRED" in log_types) and ("JOB_CANCELLED" in log_types)
    results["TEST_10"] = ("PASS" if test10_pass else "FAIL", f"Audit logs for cancel task ({len(logs)} entries): {log_types}")
    print(f"  -> Result: {results['TEST_10'][0]} ({results['TEST_10'][1]})")

    # -------------------------------------------------------------------------
    # TEST 11: Isolasi koneksi SQLite antar-thread
    # -------------------------------------------------------------------------
    print("\n[TEST 11] Thread isolation check (zero cross-thread connection sharing)...")
    # Verify get_connection creates independent objects per call/thread
    from src.hq.database import get_connection
    conn1 = get_connection(AUDIT_DB_PATH)
    conn2 = get_connection(AUDIT_DB_PATH)
    test11_pass = (conn1 is not conn2)
    conn1.close(); conn2.close()
    results["TEST_11"] = ("PASS" if test11_pass else "FAIL", f"conn1 is not conn2: {test11_pass}")
    print(f"  -> Result: {results['TEST_11'][0]} ({results['TEST_11'][1]})")

    # -------------------------------------------------------------------------
    # TEST 12: WAL mode dan transaksi atomik
    # -------------------------------------------------------------------------
    print("\n[TEST 12] WAL mode and PRAGMA integrity check...")
    test_conn = get_connection(AUDIT_DB_PATH)
    journal_mode = test_conn.execute("PRAGMA journal_mode;").fetchone()[0]
    busy_timeout = test_conn.execute("PRAGMA busy_timeout;").fetchone()[0]
    integrity_res = test_conn.execute("PRAGMA integrity_check;").fetchone()[0]
    test_conn.close()

    test12_pass = (journal_mode.lower() == "wal") and (busy_timeout == 5000) and (integrity_res == "ok")
    results["TEST_12"] = ("PASS" if test12_pass else "FAIL", f"Journal: {journal_mode}, BusyTimeout: {busy_timeout}, Integrity: {integrity_res}")
    print(f"  -> Result: {results['TEST_12'][0]} ({results['TEST_12'][1]})")

    # Summary
    print("\n======================================================================")
    print("AUDIT RESULTS SUMMARY:")
    all_passed = True
    for tid, (status, detail) in results.items():
        print(f"  {tid}: {status} - {detail}")
        if status != "PASS":
            all_passed = False
    print("======================================================================")
    print(f"OVERALL STATUS: {'ALL 12 CRITICAL TESTS PASSED' if all_passed else 'SOME TESTS FAILED'}")
    return all_passed

if __name__ == "__main__":
    success = run_critical_audit()
    if not success:
        sys.exit(1)
